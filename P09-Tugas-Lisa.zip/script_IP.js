$(document).ready(function() {
    // Menyembunyikan kotak saat halaman dimuat
    $(".kotak").hide();

    // Event untuk tombol Deskripsi
    $("#tombol1").click(function() {
        $("#kotak1").fadeToggle("slow");
    });

    // Event untuk tombol Spesifikasi
    $("#tombol2").click(function() {
        $("#kotak2").fadeToggle("slow");
    });

    // Event untuk tombol Fitur Unggulan
    $("#tombol3").click(function() {
        $("#kotak3").fadeToggle("slow");
    });
});
